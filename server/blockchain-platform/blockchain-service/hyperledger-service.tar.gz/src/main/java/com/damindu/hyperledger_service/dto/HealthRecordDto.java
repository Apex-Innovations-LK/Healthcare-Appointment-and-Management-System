package com.damindu.hyperledger_service.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class HealthRecordDto {
    private String id;
    private String patientName;
    private String dataHash;
}
