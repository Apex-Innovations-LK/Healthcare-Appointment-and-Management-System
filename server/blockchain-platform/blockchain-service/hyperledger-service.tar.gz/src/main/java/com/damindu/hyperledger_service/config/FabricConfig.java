package com.damindu.hyperledger_service.config;

import org.hyperledger.fabric.gateway.Gateway;
import org.hyperledger.fabric.gateway.Wallet;
import org.hyperledger.fabric.gateway.Wallets;
import org.hyperledger.fabric.gateway.Network;
import org.hyperledger.fabric.gateway.Contract;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.nio.file.Path;
import java.nio.file.Paths;

@Configuration
public class FabricConfig {

    @Value("${hyperledger.fabric.network-config}")
    private String networkConfigPath;
    
    @Value("${hyperledger.fabric.wallet-path}")
    private String walletPath;
    
    @Value("${hyperledger.fabric.channel}")
    private String channelName;
    
    @Value("${hyperledger.fabric.chaincode}")
    private String chaincodeName;
    
    @Value("${hyperledger.fabric.mspid}")
    private String mspId;
    
    @Value("${hyperledger.fabric.user}")
    private String username;

    @Bean
    public Gateway gateway() throws Exception {
        // Load a file system based wallet for managing identities
        Path walletPath = Paths.get(this.walletPath);
        Wallet wallet = Wallets.newFileSystemWallet(walletPath);
        
        // Load a connection profile
        Path networkConfigPath = Paths.get(this.networkConfigPath);
        
        // Configure the gateway connection
        Gateway.Builder builder = Gateway.createBuilder()
                .identity(wallet, username)
                .networkConfig(networkConfigPath)
                .discovery(true);
        
        return builder.connect();
    }

    @Bean
    public Network network(Gateway gateway) {
        return gateway.getNetwork(channelName);
    }

    @Bean
    public Contract contract(Network network) {
        return network.getContract(chaincodeName);
    }
}