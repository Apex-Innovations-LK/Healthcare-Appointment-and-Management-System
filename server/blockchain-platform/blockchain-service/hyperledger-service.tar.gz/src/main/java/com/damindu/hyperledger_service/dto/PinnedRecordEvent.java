package com.damindu.hyperledger_service.dto;

import lombok.Data;

import java.time.Instant;

@Data
public class PinnedRecordEvent {
    private String recordId;
    private String patientId;
    private String ipfsHash;
    private Instant timestamp;
    private String recordType;
}