package com.damindu.hyperledger_service.service;

import com.damindu.hyperledger_service.dto.PinnedRecordEvent;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;

@Service
public class KafkaConsumerService {

    private final BlockchainService blockchainService;

    public KafkaConsumerService(BlockchainService blockchainService) {
        this.blockchainService = blockchainService;
    }

    @KafkaListener(topics = "health.record.pinned")
    public void consumePinnedRecord(PinnedRecordEvent event, Acknowledgment ack) throws Exception {
        try {
            blockchainService.registerHealthRecord(event);
            ack.acknowledge();
        } catch (Exception e) {
            // Handle error or retry logic
            throw e;
        }
    }
}