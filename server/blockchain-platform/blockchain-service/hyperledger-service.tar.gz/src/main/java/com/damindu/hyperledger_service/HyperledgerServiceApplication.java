package com.damindu.hyperledger_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HyperledgerServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(HyperledgerServiceApplication.class, args);
	}

}
