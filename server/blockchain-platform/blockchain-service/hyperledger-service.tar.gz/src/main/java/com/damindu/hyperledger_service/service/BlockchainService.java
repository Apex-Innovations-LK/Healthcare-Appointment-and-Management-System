package com.damindu.hyperledger_service.service;

import com.damindu.hyperledger_service.dto.PinnedRecordEvent;
import org.hyperledger.fabric.gateway.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.nio.file.Path;
import java.nio.file.Paths;
// import java.util.concurrent.TimeUnit;

@Service
public class BlockchainService {

    @Value("${hyperledger.fabric.network-config}")
    private String networkConfigPath;
    
    @Value("${hyperledger.fabric.wallet-path}")
    private String walletPath;
    
    @Value("${hyperledger.fabric.channel}")
    private String channelName;
    
    @Value("${hyperledger.fabric.chaincode}")
    private String chaincodeName;
    
    @Value("${hyperledger.fabric.mspid}")
    private String mspId;
    
    @Value("${hyperledger.fabric.user}")
    private String username;
    
    private Gateway gateway;
    private Network network;
    private Contract contract;

    @PostConstruct
    public void initialize() throws Exception {
        // Load a file system based wallet for managing identities.
        Path walletDirectory = Paths.get(walletPath);
        Wallet wallet = Wallets.newFileSystemWallet(walletDirectory);
        
        // Load connection profile
        Path networkConfigFile = Paths.get(networkConfigPath);
        
        Gateway.Builder builder = Gateway.createBuilder()
                .identity(wallet, username)
                .networkConfig(networkConfigFile)
                .discovery(true);
        
        gateway = builder.connect();
        network = gateway.getNetwork(channelName);
        contract = network.getContract(chaincodeName);
    }

    public void registerHealthRecord(PinnedRecordEvent event) throws Exception {
        try {
            // Submit transaction to the ledger
            byte[] result = contract.createTransaction("registerHealthRecord")
                    .submit(event.getRecordId(), 
                           event.getPatientId(), 
                           event.getIpfsHash(), 
                           event.getTimestamp().toString(),
                           event.getRecordType());
            
            System.out.println("Transaction submitted: " + new String(result));
            
            // Optionally publish health.record.registered event
        } catch (Exception e) {
            System.err.println("Error submitting transaction: " + e.getMessage());
            throw e;
        }
    }

    public String queryHealthRecord(String recordId) throws Exception {
        byte[] result = contract.evaluateTransaction("queryHealthRecord", recordId);
        return new String(result);
    }
}