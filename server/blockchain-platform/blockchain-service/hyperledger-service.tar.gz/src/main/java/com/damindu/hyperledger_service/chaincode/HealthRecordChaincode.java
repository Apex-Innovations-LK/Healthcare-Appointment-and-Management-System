package com.damindu.hyperledger_service.chaincode;

import org.hyperledger.fabric.gateway.Contract;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeoutException;

@Component
public class HealthRecordChaincode {

    private final Contract contract;

    public HealthRecordChaincode(Contract contract) {
        this.contract = contract;
    }

    public String registerHealthRecord(String recordId, String patientId, String ipfsHash, 
                                      String timestamp, String recordType) 
            throws Exception {
        try {
            byte[] result = contract.submitTransaction("registerHealthRecord", 
                    recordId, patientId, ipfsHash, timestamp, recordType);
            return new String(result);
        } catch (TimeoutException e) {
            throw new Exception("Transaction timed out: " + e.getMessage());
        } catch (Exception e) {
            throw new Exception("Error submitting transaction: " + e.getMessage());
        }
    }

    public String queryHealthRecord(String recordId) throws Exception {
        try {
            byte[] result = contract.evaluateTransaction("queryHealthRecord", recordId);
            return new String(result);
        } catch (Exception e) {
            throw new Exception("Error evaluating transaction: " + e.getMessage());
        }
    }
}