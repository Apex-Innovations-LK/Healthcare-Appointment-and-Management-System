package com.damindu.hyperledger_service.utils;

import org.hyperledger.fabric.gateway.Wallet;
import org.hyperledger.fabric.gateway.Wallets;
import org.hyperledger.fabric.gateway.Identities;
import org.hyperledger.fabric.gateway.Identity;
// import org.hyperledger.fabric.sdk.Enrollment;
// import org.hyperledger.fabric.sdk.security.CryptoSuite;
// import org.hyperledger.fabric.sdk.security.CryptoSuiteFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.PrivateKey;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

@Component
public class FabricWalletInitializer {

    @Value("${hyperledger.fabric.wallet-path}")
    private String walletPath;
    
    @Value("${hyperledger.fabric.keystore-path}")
    private String keystorePath;
    
    @Value("${hyperledger.fabric.mspid}")
    private String mspId;
    
    @Value("${hyperledger.fabric.admin-cert-path}")
    private String adminCertPath;
    
    @Value("${hyperledger.fabric.admin-key-path}")
    private String adminKeyPath;

    @PostConstruct
    public void initializeWallet() throws Exception {
        Path walletDir = Paths.get(walletPath);
        if (!Files.exists(walletDir)) {
            Files.createDirectories(walletDir);
        }

        Wallet wallet = Wallets.newFileSystemWallet(walletDir);
        
        // Check if identity already exists
        if (wallet.get("admin") == null) {
            // Load the certificate and private key
            X509Certificate certificate = readX509Certificate(Paths.get(adminCertPath));
            PrivateKey privateKey = readPrivateKey(Paths.get(adminKeyPath));
            
            // Create the identity
            Identity identity = Identities.newX509Identity(mspId, certificate, privateKey);
            
            // Put it in the wallet
            wallet.put("admin", identity);
            System.out.println("Added admin identity to wallet");
        }
    }

    private X509Certificate readX509Certificate(Path certPath) throws CertificateException, IOException {
        String certPem = Files.readString(certPath);
        return Identities.readX509Certificate(certPem);
    }
    
    private PrivateKey readPrivateKey(Path keyPath) throws Exception {
        String keyPem = Files.readString(keyPath); 
        return Identities.readPrivateKey(keyPem);
    }
    
}