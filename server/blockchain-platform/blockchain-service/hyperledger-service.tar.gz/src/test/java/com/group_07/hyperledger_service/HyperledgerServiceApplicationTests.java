package com.group_07.hyperledger_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HyperledgerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
