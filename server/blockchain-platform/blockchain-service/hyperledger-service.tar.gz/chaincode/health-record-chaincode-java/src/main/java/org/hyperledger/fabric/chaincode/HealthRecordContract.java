package org.hyperledger.fabric.chaincode;

import org.hyperledger.fabric.contract.Context;
import org.hyperledger.fabric.contract.ContractInterface;
import org.hyperledger.fabric.contract.annotation.Contract;
import org.hyperledger.fabric.contract.annotation.Default;
import org.hyperledger.fabric.contract.annotation.Transaction;
import org.hyperledger.fabric.shim.ChaincodeException;
import org.hyperledger.fabric.shim.ChaincodeStub;
import com.owlike.genson.Genson;

@Contract(name = "HealthRecordContract")
@Default
public class HealthRecordContract implements ContractInterface {
    private final Genson genson = new Genson();

    @Transaction(intent = Transaction.TYPE.SUBMIT)
    public void registerHealthRecord(final Context ctx, String recordId, 
                                   String patientId, String ipfsHash, 
                                   String timestamp, String recordType) {
        ChaincodeStub stub = ctx.getStub();
        
        if (recordId == null || recordId.isEmpty()) {
            throw new ChaincodeException("Record ID cannot be empty");
        }
        
        if (patientId == null || patientId.isEmpty()) {
            throw new ChaincodeException("Patient ID cannot be empty");
        }
        
        if (ipfsHash == null || ipfsHash.isEmpty()) {
            throw new ChaincodeException("IPFS hash cannot be empty");
        }
        
        String recordState = genson.serialize(new HealthRecord(recordId, patientId, 
                ipfsHash, timestamp, recordType));
        
        stub.putStringState(recordId, recordState);
    }

    @Transaction(intent = Transaction.TYPE.EVALUATE)
    public HealthRecord queryHealthRecord(final Context ctx, String recordId) {
        ChaincodeStub stub = ctx.getStub();
        String recordState = stub.getStringState(recordId);
        
        if (recordState == null || recordState.isEmpty()) {
            throw new ChaincodeException("Record does not exist: " + recordId);
        }
        
        return genson.deserialize(recordState, HealthRecord.class);
    }
}

class HealthRecord {
    private String recordId;
    private String patientId;
    private String ipfsHash;
    private String timestamp;
    private String recordType;

    public HealthRecord(String recordId, String patientId, String ipfsHash, 
                       String timestamp, String recordType) {
        this.recordId = recordId;
        this.patientId = patientId;
        this.ipfsHash = ipfsHash;
        this.timestamp = timestamp;
        this.recordType = recordType;
    }

    // Getters and setters
    public String getRecordId() { return recordId; }
    public void setRecordId(String recordId) { this.recordId = recordId; }
    public String getPatientId() { return patientId; }
    public void setPatientId(String patientId) { this.patientId = patientId; }
    public String getIpfsHash() { return ipfsHash; }
    public void setIpfsHash(String ipfsHash) { this.ipfsHash = ipfsHash; }
    public String getTimestamp() { return timestamp; }
    public void setTimestamp(String timestamp) { this.timestamp = timestamp; }
    public String getRecordType() { return recordType; }
    public void setRecordType(String recordType) { this.recordType = recordType; }
}